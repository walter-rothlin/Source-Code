#!/usr/bin/env python3
"""Gekürzte Unterrichtsklasse für die MLZ PY2 2026, Konstantinos Smyrlis.

Vorlage und ursprünglicher Autor: Walter Rothlin.
Quelle: https://raw.githubusercontent.com/walter-rothlin/RaspberryPi4PiPlates/refs/heads/main/My_Packages/Class_MySenseHat.py
"""

from enum import Enum
from math import isfinite
from time import sleep

from sense_hat import SenseHat


class LogLevel(Enum):
    ALLWAYS = 0
    INFO = 1
    WARNING = 2
    ERROR = 3
    FATAL = 4
    NO_TRACE = 9


class MySenseHat(SenseHat):
    """SenseHat mit toleranter Pixelverarbeitung und einer Linienfunktion."""

    def __init__(self, default_bg_color=(0, 255, 255),
                 default_fg_color=(255, 0, 0), trace_level_on=LogLevel.WARNING):
        self.__default_bg_color = default_bg_color
        self.__default_fg_color = default_fg_color
        self.__trace_level_on = trace_level_on
        super().__init__()

    def set_debug_mode(self, trace_level_on):
        self.__trace_level_on = trace_level_on

    def get_debug_mode(self):
        return self.__trace_level_on

    debug_mode = property(get_debug_mode, set_debug_mode)

    def clear(self, *colour):
        """Ohne Farbe die eingestellte Hintergrundfarbe verwenden."""
        if not colour:
            colour = (self.__default_bg_color,)
        super().clear(*colour)

    @staticmethod
    def _rounded_integer(value):
        """Numerische Werte einschließlich Dezimalkomma auf ganze Zahlen runden."""
        if isinstance(value, str):
            value = value.strip().replace(',', '.')
        return round(float(value))

    def set_pixel(self, x, y, r=None, g=None, b=None, pixel_color=None):
        """Außerhalb liegende Pixel ignorieren und RGB auf 0 bis 255 begrenzen.

        Farben als r/g/b, Tupel/Liste oder pixel_color=(r,g,b) annehmen.
        Ungültige Zahlen ändern die Matrix nicht.
        """
        try:
            x = self._rounded_integer(x)
            y = self._rounded_integer(y)
        except (TypeError, ValueError, OverflowError):
            return
        if not (0 <= x < 8 and 0 <= y < 8):
            return

        if pixel_color is None and isinstance(r, (tuple, list)) and g is None and b is None:
            pixel_color = r
        if pixel_color is None:
            pixel_color = tuple(
                default if component is None else component
                for component, default in zip((r, g, b), self.__default_fg_color)
            )
        try:
            if len(pixel_color) != 3:
                return
            colour = tuple(max(0, min(255, self._rounded_integer(component)))
                           for component in pixel_color)
        except (TypeError, ValueError, OverflowError):
            return
        super().set_pixel(x, y, *colour)

    def draw_line(self, x_start=0, y_start=0, x_end=7, y_end=7,
                  r=255, g=255, b=255, draw_speed=0):
        """Bresenham-Linie inklusive Endpunkten zeichnen; äußere Pixel überspringen."""
        try:
            x_start, y_start, x_end, y_end = (
                self._rounded_integer(value)
                for value in (x_start, y_start, x_end, y_end)
            )
            draw_speed = float(draw_speed) if draw_speed not in (None, '') else 0
            if not isfinite(draw_speed) or draw_speed < 0:
                raise ValueError('draw_speed muss endlich und nicht negativ sein.')
        except (TypeError, ValueError, OverflowError) as error:
            raise ValueError('Ungültige Linienkoordinaten oder Geschwindigkeit.') from error

        delta_x = abs(x_end - x_start)
        delta_y = -abs(y_end - y_start)
        step_x = 1 if x_start < x_end else -1
        step_y = 1 if y_start < y_end else -1
        line_error = delta_x + delta_y
        x, y = x_start, y_start

        while True:
            if 0 <= x < 8 and 0 <= y < 8:
                self.set_pixel(x, y, r, g, b)
                if draw_speed:
                    sleep(draw_speed)
            if x == x_end and y == y_end:
                break
            doubled_error = 2 * line_error
            if doubled_error >= delta_y:
                line_error += delta_y
                x += step_x
            if doubled_error <= delta_x:
                line_error += delta_x
                y += step_y
