#!/usr/bin/env python3
"""Sense-HAT-Websteuerung für die MLZ PY2 2026, Konstantinos Smyrlis.

Ausgangslage: 01_SenseHat_Flask.py von Walter Rothlin (08.10.2025).
Start: python3 MLZ_PY2_2026_Smyrlis_Konstantinos.py
Tests: python3 -m unittest discover -s tests -v
"""

from datetime import datetime
import json
import math
import os
from zoneinfo import ZoneInfo

from flask import Flask, jsonify, render_template, request
import webcolors

from Class_MySenseHat import MySenseHat


version = 'Konstantinos Smyrlis (V1.0, MLZ PY2 2026)'
HOST = os.environ.get('MLZ_HOST', '0.0.0.0')
PORT = 5002
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
MAX_LINE_COORDINATE = 10_000
request_log = []


def parameters():
    """GET, Formular-POST und JSON-POST mit derselben Schnittstelle lesen."""
    if request.is_json:
        values = request.get_json()
        if not isinstance(values, dict):
            raise ValueError('JSON muss ein Objekt mit benannten Parametern sein.')
        return values
    return request.form.to_dict() if request.method == 'POST' else request.args.to_dict()


def to_float(value, default=None, minimum=None, maximum=None):
    """Endliche Zahl lesen; Dezimalkomma und Schweizer Tausendertrenner zulassen."""
    try:
        if isinstance(value, str):
            value = value.strip().replace(' ', '').replace("'", '').replace(',', '.')
        number = float(value)
        if not math.isfinite(number):
            return default
        if minimum is not None and number < minimum:
            return minimum
        if maximum is not None and number > maximum:
            return maximum
        return number
    except (TypeError, ValueError, OverflowError):
        return default


def to_integer(value, default=None, minimum=None, maximum=None):
    """Eine Zahl wie in MySenseHat auf die nächste ganze Zahl runden."""
    number = to_float(value, minimum=minimum, maximum=maximum)
    return default if number is None else round(number)


def to_boolean(value, default=None):
    if isinstance(value, str):
        value = value.strip().lower()
        if value in ('1', 'true', 'yes', 'y'):
            return True
        if value in ('0', 'false', 'no', 'n'):
            return False
    elif isinstance(value, (bool, int, float)):
        return bool(value)
    return default


def to_rgb(value, default=None, *, clamp=True):
    """CSS-Farbe, Hex, RGB-Tupel/Liste oder Grauwert in RGB umwandeln.

    Bei set_pixel übernimmt MySenseHat selbst die Begrenzung der RGB-Werte.
    Die anderen Sense-HAT-Methoden benötigen bereits gültige Farbkanäle.
    """
    if isinstance(value, str):
        colour = value.strip().replace("'", '')
        compact = colour.replace(' ', '').lower()
        try:
            return tuple(webcolors.name_to_rgb(compact))
        except ValueError:
            pass
        hexadecimal = compact.lstrip('#')
        if len(hexadecimal) == 6 and all(char in '0123456789abcdef' for char in hexadecimal):
            return tuple(int(hexadecimal[index:index + 2], 16) for index in (0, 2, 4))
        # Auch die unvollständigen Klammern aus den vorbereiteten Tests zulassen.
        colour = colour.translate(str.maketrans('', '', '()[]'))
        value = colour.split(',') if ',' in colour else colour.split()
    elif isinstance(value, (int, float)):
        value = (value, value, value)
    if not isinstance(value, (tuple, list)) or len(value) != 3:
        return default
    channels = tuple(to_float(channel) for channel in value)
    if any(channel is None for channel in channels):
        return default
    if clamp:
        return tuple(int(max(0, min(255, round(channel)))) for channel in channels)
    return channels


app = Flask(__name__)
# Echte Hardware verwenden; ein fehlendes Gerät nicht stillschweigend simulieren.
hardware_error = None
try:
    sense = MySenseHat(default_bg_color=BLACK)
    sense.clear(BLACK)
except OSError as error:
    sense = None
    hardware_error = f'Sense HAT nicht verfügbar: {error}. Bitte Anschluss und Erkennung prüfen und die App neu starten.'


@app.before_request
def log_request():
    """Aufrufe protokollieren und fehlende Hardware verständlich melden."""
    if request.endpoint is not None and request.endpoint != 'static':
        timestamp = datetime.now(ZoneInfo('Europe/Zurich')).strftime('%d-%m-%y %H:%M:%S')
        request_log.append(f'{timestamp}: {request.method}: {request.endpoint}({parameters()})')
        # Das Log bleibt auch nach vielen Klicks überschaubar.
        del request_log[:-500]
        if sense is None and request.endpoint not in ('index', 'led_matrix_tester'):
            return index_page(error=hardware_error), 503


def index_page(error=None):
    return render_template('index.html', version=version, request_log=request_log,
                           error=error or hardware_error)


@app.errorhandler(ValueError)
def invalid_parameter(error):
    return index_page(error=str(error)), 400


def meteo_sensor_values():
    """Ein gemeinsames Format für Status, einzelne Sensoren und Wetterseite."""
    return {
        'Temperature': {'value': sense.get_temperature(), 'unit': '°C'},
        'Humidity': {'value': sense.get_humidity(), 'unit': '%'},
        'Pressure': {'value': sense.get_pressure(), 'unit': 'mBar'},
    }


def pixel_colour(values, *, clamp=True):
    """Sowohl pixel=(r,g,b) als auch getrennte r/g/b unterstützen."""
    if 'pixel' in values:
        colour = to_rgb(values['pixel'], clamp=clamp)
    else:
        colour = to_rgb(tuple(values.get(channel, 255) for channel in ('r', 'g', 'b')),
                        clamp=clamp)
    if colour is None:
        raise ValueError('Die Farbe muss drei numerische RGB-Werte enthalten.')
    return colour


@app.route('/get_status', methods=['GET', 'POST'])
def get_status():
    return jsonify(LED_Matrix=sense.get_pixels(), **meteo_sensor_values())


@app.route('/set_rotation', methods=['GET', 'POST'])
def set_rotation():
    values = parameters()
    rotation = to_float(values.get('r'), 0)
    if rotation not in (0, 90, 180, 270):
        rotation = 0
    sense.set_rotation(int(rotation), redraw=to_boolean(values.get('redraw'), True))
    return index_page()


@app.route('/flip_h', methods=['GET', 'POST'])
def flip_h():
    sense.flip_h(redraw=to_boolean(parameters().get('redraw'), True))
    return index_page()


@app.route('/flip_v', methods=['GET', 'POST'])
def flip_v():
    sense.flip_v(redraw=to_boolean(parameters().get('redraw'), True))
    return index_page()


@app.route('/set_pixels', methods=['GET', 'POST'])
def set_pixels():
    """Optional: eine vollständige 8×8-Matrix als JSON-Liste übernehmen."""
    pixels = parameters().get('pixel_list')
    if isinstance(pixels, str):
        try:
            pixels = json.loads(pixels)
        except json.JSONDecodeError as error:
            raise ValueError('pixel_list muss eine JSON-Liste mit 64 Farben sein.') from error
    if not isinstance(pixels, list) or len(pixels) != 64:
        raise ValueError('pixel_list muss genau 64 Farben enthalten.')
    colours = [to_rgb(pixel) for pixel in pixels]
    if any(colour is None for colour in colours):
        raise ValueError('Jeder Pixel muss eine gültige RGB-Farbe enthalten.')
    sense.set_pixels(colours)
    return index_page()


@app.route('/get_pixels', methods=['GET', 'POST'])
def get_pixels():
    return jsonify(sense.get_pixels())


@app.route('/set_pixel', methods=['GET', 'POST'])
def set_pixel():
    values = parameters()
    x = to_integer(values.get('x'), 0)
    y = to_integer(values.get('y'), 0)
    # Unbegrenzte Farbkanäle weiterreichen: die Unterklasse behandelt Grenzwerte.
    sense.set_pixel(x, y, pixel_color=pixel_colour(values, clamp=False))
    return index_page()


@app.route('/get_pixel', methods=['GET', 'POST'])
def get_pixel():
    values = parameters()
    x = to_integer(values.get('x'), 0)
    y = to_integer(values.get('y'), 0)
    if not (0 <= x <= 7 and 0 <= y <= 7):
        raise ValueError('get_pixel benötigt x und y zwischen 0 und 7.')
    return jsonify(sense.get_pixel(x, y))


@app.route('/clear', methods=['GET', 'POST'])
def clear():
    values = parameters()
    colour = to_rgb(values.get('colour', values.get('color')), BLACK)
    sense.clear(colour)
    return index_page()


@app.route('/show_message', methods=['GET', 'POST'])
def show_message():
    values = parameters()
    text = str(values.get('text_string', 'Hallo'))
    speed = to_float(values.get('scroll_speed'), 0.1, minimum=0.01, maximum=1)
    sense.show_message(text_string=text, scroll_speed=speed,
                       text_colour=to_rgb(values.get('text_colour'), WHITE),
                       back_colour=to_rgb(values.get('back_colour'), BLACK))
    return index_page()


@app.route('/show_letter', methods=['GET', 'POST'])
def show_letter():
    values = parameters()
    letter = (str(values.get('s', '?')) or '?')[0]
    sense.show_letter(s=letter, text_colour=to_rgb(values.get('text_colour'), WHITE),
                      back_colour=to_rgb(values.get('back_colour'), BLACK))
    return index_page()


@app.route('/draw_line', methods=['GET', 'POST'])
def draw_line():
    values = parameters()
    coordinates = {
        name: to_integer(values.get(name), default, minimum=-MAX_LINE_COORDINATE,
                         maximum=MAX_LINE_COORDINATE)
        for name, default in (('x_start', 0), ('y_start', 0), ('x_end', 7), ('y_end', 7))
    }
    r, g, b = pixel_colour(values)
    speed = to_float(values.get('draw_speed'), 0, minimum=0, maximum=1)
    sense.draw_line(**coordinates, r=r, g=g, b=b, draw_speed=speed)
    return index_page()


@app.route('/get_temprature', methods=['GET', 'POST'])
@app.route('/get_temperature', methods=['GET', 'POST'])
def get_temperature():
    # Den Tippfehler aus dem Kriterienblatt ebenfalls als URL unterstützen.
    return jsonify(Temperature={'value': sense.get_temperature(), 'unit': '°C'})


@app.route('/get_pressure', methods=['GET', 'POST'])
def get_pressure():
    return jsonify(Pressure={'value': sense.get_pressure(), 'unit': 'mBar'})


@app.route('/get_humidity', methods=['GET', 'POST'])
def get_humidity():
    return jsonify(Humidity={'value': sense.get_humidity(), 'unit': '%'})


@app.route('/get_meteo_sensor_values', methods=['GET', 'POST'])
def get_meteo_sensor_values():
    return jsonify(meteo_sensor_values())


@app.route('/get_weather', methods=['GET', 'POST'])
def get_weather():
    return render_template('weather.html', weather=meteo_sensor_values(), version=version)


@app.route('/')
def index():
    return index_page()


@app.route('/LED_Matrix_Tester')
def led_matrix_tester():
    return render_template('LED_Matrix_Tester.html')


if __name__ == '__main__':
    # Alle Netzwerkschnittstellen; auf diesem RPi: http://192.168.1.70:5002/
    # Kein Reloader: die Hardware soll nur einmal initialisiert werden.
    if hardware_error:
        print(hardware_error)
    app.run(host=HOST, port=PORT, debug=False, threaded=False)
