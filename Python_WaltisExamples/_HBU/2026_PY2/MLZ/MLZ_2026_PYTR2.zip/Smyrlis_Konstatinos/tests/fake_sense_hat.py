"""Kleiner Hardware-Ersatz: Die produktive MySenseHat-Klasse bleibt im Test aktiv."""


class FakeSenseHat:
    def __init__(self, *args, **kwargs):
        self.pixels = [[0, 0, 0] for _ in range(64)]
        self.rotation = 0
        self.last_letter = None
        self.last_message = None
        self.last_redraw = True

    def clear(self, *colour):
        if not colour:
            colour = (0, 0, 0)
        elif len(colour) == 1:
            colour = colour[0]
        self.pixels = [list(colour) for _ in range(64)]

    def set_pixel(self, x, y, *colour):
        if not isinstance(x, int) or not isinstance(y, int) or not 0 <= x < 8 or not 0 <= y < 8:
            raise ValueError('Pixel ausserhalb der Matrix')
        if len(colour) == 1:
            colour = colour[0]
        if len(colour) != 3 or any(type(c) is not int or not 0 <= c <= 255 for c in colour):
            raise ValueError('Ungueltige RGB-Farbe')
        self.pixels[y * 8 + x] = list(colour)

    def get_pixel(self, x, y):
        if not 0 <= x < 8 or not 0 <= y < 8:
            raise ValueError('Pixel ausserhalb der Matrix')
        return list(self.pixels[y * 8 + x])

    def get_pixels(self):
        return [list(pixel) for pixel in self.pixels]

    def set_pixels(self, pixels):
        if len(pixels) != 64:
            raise ValueError('Es werden 64 Pixel benoetigt')
        self.pixels = [list(pixel) for pixel in pixels]

    def set_rotation(self, r=0, redraw=True):
        if r not in (0, 90, 180, 270):
            raise ValueError('Ungueltige Rotation')
        self.rotation = r
        self.last_redraw = redraw

    def flip_h(self, redraw=True):
        pixels = [self.pixels[y * 8 + 7 - x] for y in range(8) for x in range(8)]
        if redraw:
            self.set_pixels(pixels)
        self.last_redraw = redraw
        return pixels

    def flip_v(self, redraw=True):
        pixels = [self.pixels[(7 - y) * 8 + x] for y in range(8) for x in range(8)]
        if redraw:
            self.set_pixels(pixels)
        self.last_redraw = redraw
        return pixels

    def show_letter(self, s, text_colour=(255, 255, 255), back_colour=(0, 0, 0)):
        if len(s) != 1:
            raise ValueError('Genau ein Zeichen erwartet')
        self.last_letter = (s, tuple(text_colour), tuple(back_colour))

    def show_message(self, text_string, scroll_speed=0.1, text_colour=(255, 255, 255), back_colour=(0, 0, 0)):
        self.last_message = (text_string, scroll_speed, tuple(text_colour), tuple(back_colour))

    def get_temperature(self):
        return 21.5

    def get_humidity(self):
        return 45.0

    def get_pressure(self):
        return 1013.25
