"""Hardwarefreie Tests der Sense-HAT-Webanwendung."""
