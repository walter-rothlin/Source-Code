"""Akzeptanztests; aus MLZ_2026_PY2: python3 -m unittest discover -s tests -v.

Nur die Hardware wird ersetzt. Flask-Routen, Parameterverarbeitung, Jinja und
die produktive MySenseHat-Unterklasse werden gemeinsam ausgefuehrt.
"""

import importlib.util
from pathlib import Path
import sys
import types
import unittest
from html.parser import HTMLParser
from unittest.mock import patch

try:
    from tests.fake_sense_hat import FakeSenseHat
except ImportError:
    from fake_sense_hat import FakeSenseHat


PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT))


class PageControls(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []
        self.forms = []
        self.form = None

    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        if tag == 'a' and values.get('href', '').startswith('/'):
            self.links.append(values['href'])
        elif tag == 'form':
            self.form = {'action': values.get('action', '/'), 'data': {}}
        elif tag == 'input' and self.form is not None and 'name' in values:
            self.form['data'][values['name']] = values.get('value', '')

    def handle_endtag(self, tag):
        if tag == 'form' and self.form is not None:
            self.forms.append(self.form)
            self.form = None


class ApplicationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        source = PROJECT / 'MLZ_PY2_2026_Smyrlis_Konstantinos.py'
        fake_module = types.ModuleType('sense_hat')
        fake_module.SenseHat = FakeSenseHat
        cls.hardware_patch = patch.dict(sys.modules, {'sense_hat': fake_module})
        cls.hardware_patch.start()
        cls.addClassCleanup(cls.hardware_patch.stop)
        # Avoid reusing a class imported against a real device by another test.
        sys.modules.pop('Class_MySenseHat', None)
        spec = importlib.util.spec_from_file_location('sense_hat_application_under_test', source)
        cls.module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = cls.module
        spec.loader.exec_module(cls.module)
        cls.app = cls.module.app
        cls.app.config.update(TESTING=True)
        sense_module = sys.modules.get('Class_MySenseHat')
        if sense_module is not None and hasattr(sense_module, 'sleep'):
            sleeper = patch.object(sense_module, 'sleep', return_value=None)
            sleeper.start()
            cls.addClassCleanup(sleeper.stop)

    def setUp(self):
        self.client = self.app.test_client()
        self.sense = self.module.sense
        self.sense.clear((0, 0, 0))
        self.sense.rotation = 0
        self.sense.last_letter = None
        self.sense.last_message = None
        self.module.request_log.clear()

    def test_get_pixels_returns_64_rgb_values(self):
        response = self.client.get('/get_pixels')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json(), [[0, 0, 0]] * 64)

    def test_set_and_get_pixel_separate_rgb(self):
        self.assertEqual(self.client.get('/set_pixel?x=2&y=4&r=255&g=255&b=0').status_code, 200)
        self.assertEqual(self.client.get('/get_pixel?x=2&y=4').get_json(), [255, 255, 0])

    def test_set_pixel_tuple_and_decimal_channel(self):
        response = self.client.get('/set_pixel', query_string={'x': 5, 'y': 6, 'pixel': '(255, -10.5, 255)'})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.sense.get_pixel(5, 6), [255, 0, 255])

    def test_rgb_channels_are_limited(self):
        self.client.get('/set_pixel?x=4&y=6&r=300&g=-10&b=255')
        self.assertEqual(self.sense.get_pixel(4, 6), [255, 0, 255])

    def test_outside_pixels_do_not_change_matrix(self):
        before = self.sense.get_pixels()
        for x, y in [(8, 4), (0, 8), (-1, 3), (3, -1)]:
            with self.subTest(x=x, y=y):
                self.assertEqual(self.client.get('/set_pixel', query_string={'x': x, 'y': y, 'r': 255}).status_code, 200)
                self.assertEqual(self.sense.get_pixels(), before)

    def test_set_pixel_accepts_post_form_and_json(self):
        for options in [{'data': {'x': 1, 'y': 2, 'r': 255, 'g': 0, 'b': 0}},
                        {'json': {'x': 1, 'y': 2, 'pixel': [255, 0, 0]}}]:
            with self.subTest(options=options):
                self.sense.clear((0, 0, 0))
                self.assertEqual(self.client.post('/set_pixel', **options).status_code, 200)
                self.assertEqual(self.sense.get_pixel(1, 2), [255, 0, 0])

    def test_rotation_valid_and_invalid_values(self):
        cases = [(0, 0), (90, 90), (180, 180), (270, 270), (135, 0),
                 (90.5, 0), (-90, 0), (360, 0), ('ungueltig', 0), ('nan', 0), ('inf', 0)]
        for value, expected in cases:
            with self.subTest(rotation=value):
                self.assertEqual(self.client.get('/set_rotation', query_string={'r': value, 'redraw': 'True'}).status_code, 200)
                self.assertEqual(self.sense.rotation, expected)

    def test_redraw_false_is_a_boolean(self):
        self.client.post('/set_rotation', json={'r': 90, 'redraw': False})
        self.assertEqual(self.sense.rotation, 90)
        self.assertIs(self.sense.last_redraw, False)
        self.client.get('/set_rotation?r=180&redraw=False')
        self.assertEqual(self.sense.rotation, 180)
        self.assertIs(self.sense.last_redraw, False)

    def test_flip_redraw_false_keeps_matrix_unchanged(self):
        self.sense.set_pixel(1, 2, 255, 0, 0)
        before = self.sense.get_pixels()
        for endpoint in ('/flip_h', '/flip_v'):
            with self.subTest(endpoint=endpoint):
                self.assertEqual(self.client.get(endpoint + '?redraw=False').status_code, 200)
                self.assertIs(self.sense.last_redraw, False)
                self.assertEqual(self.sense.get_pixels(), before)

    def test_flip_h_moves_pixel(self):
        self.sense.set_pixel(1, 2, 255, 0, 0)
        self.client.get('/flip_h?redraw=True')
        self.assertEqual(self.sense.get_pixel(6, 2), [255, 0, 0])
        self.assertEqual(self.sense.get_pixel(1, 2), [0, 0, 0])

    def test_flip_v_moves_pixel(self):
        self.sense.set_pixel(1, 2, 255, 0, 0)
        self.client.get('/flip_v?redraw=True')
        self.assertEqual(self.sense.get_pixel(1, 5), [255, 0, 0])
        self.assertEqual(self.sense.get_pixel(1, 2), [0, 0, 0])

    def test_clear_colour_formats(self):
        for value, expected in [('blue', [0, 0, 255]), ('#ffff00', [255, 255, 0]),
                                ('(255, 0, 255)', [255, 0, 255]), ('0 128 255', [0, 128, 255])]:
            with self.subTest(colour=value):
                self.assertEqual(self.client.get('/clear', query_string={'colour': value}).status_code, 200)
                self.assertEqual(self.sense.get_pixels(), [expected] * 64)
        self.client.get('/clear')
        self.assertEqual(self.sense.get_pixels(), [[0, 0, 0]] * 64)

    def test_show_message_passes_text_speed_and_colours(self):
        response = self.client.post('/show_message', data={
            'text_string': 'Hallo HBU', 'scroll_speed': '0.2',
            'text_colour': '(255,0,255)', 'back_colour': '(0,0,10)',
        })
        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.sense.last_message, ('Hallo HBU', 0.2, (255, 0, 255), (0, 0, 10)))

    def test_show_letter_uses_first_character_and_handles_empty_input(self):
        self.client.post('/show_letter', data={'s': 'Ys', 'text_colour': '#FF ff 00', 'back_colour': 'xxxx'})
        self.assertEqual(self.sense.last_letter, ('Y', (255, 255, 0), (0, 0, 0)))
        self.assertEqual(self.client.get('/show_letter?s=').status_code, 200)
        self.assertEqual(len(self.sense.last_letter[0]), 1)

    def test_environment_endpoints(self):
        for endpoint, key, value, unit in [('/get_temperature', 'Temperature', 21.5, '°C'),
                                            ('/get_pressure', 'Pressure', 1013.25, 'mBar'),
                                            ('/get_humidity', 'Humidity', 45.0, '%')]:
            with self.subTest(endpoint=endpoint):
                response = self.client.get(endpoint)
                self.assertEqual(response.status_code, 200)
                self.assertEqual(response.get_json(), {key: {'value': value, 'unit': unit}})

    def test_temperature_typo_from_criteria_remains_accessible(self):
        self.assertEqual(self.client.get('/get_temprature').get_json(),
                         self.client.get('/get_temperature').get_json())

    def test_non_object_and_malformed_json_are_bad_requests(self):
        before = self.sense.get_pixels()
        for options in [{'json': [1, 2, 3]},
                        {'data': '{"x":', 'content_type': 'application/json'}]:
            with self.subTest(options=options):
                self.assertEqual(self.client.post('/set_pixel', **options).status_code, 400)
                self.assertEqual(self.sense.get_pixels(), before)

    def test_get_pixel_outside_matrix_returns_bad_request(self):
        for x, y in [(-1, 0), (8, 0), (0, -1), (0, 8)]:
            with self.subTest(x=x, y=y):
                self.assertEqual(self.client.get('/get_pixel', query_string={'x': x, 'y': y}).status_code, 400)

    def test_set_pixels_validates_entire_matrix_before_writing(self):
        pixels = [[255, 0, 0]] + [[0, 0, 255]] * 63
        self.assertEqual(self.client.post('/set_pixels', json={'pixel_list': pixels}).status_code, 200)
        self.assertEqual(self.sense.get_pixels(), pixels)
        for invalid in [pixels[:63], [[255, 0, 0]] * 63 + ['ungueltig'], 'keine JSON-Liste']:
            with self.subTest(invalid=invalid):
                self.assertEqual(self.client.post('/set_pixels', json={'pixel_list': invalid}).status_code, 400)
                self.assertEqual(self.sense.get_pixels(), pixels)

    def test_meteo_and_status_include_live_values(self):
        expected = {'Temperature': {'value': 21.5, 'unit': '°C'},
                    'Pressure': {'value': 1013.25, 'unit': 'mBar'},
                    'Humidity': {'value': 45.0, 'unit': '%'}}
        self.assertEqual(self.client.get('/get_meteo_sensor_values').get_json(), expected)
        expected['LED_Matrix'] = self.sense.get_pixels()
        self.assertEqual(self.client.get('/get_status').get_json(), expected)

    def test_weather_html_contains_sensor_values(self):
        response = self.client.get('/get_weather')
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.content_type.startswith('text/html'))
        for value in ['21.5', '45', '1013.25']:
            self.assertIn(value, response.get_data(as_text=True))

    def test_missing_hardware_keeps_index_available_and_returns_503_for_devices(self):
        message = 'Sense HAT nicht verfügbar: Testgeraet fehlt.'
        with patch.object(self.module, 'sense', None), patch.object(self.module, 'hardware_error', message):
            response = self.client.get('/')
            self.assertEqual(response.status_code, 200)
            self.assertIn(message, response.get_data(as_text=True))
            self.assertEqual(self.client.get('/LED_Matrix_Tester').status_code, 200)
            for endpoint in ('/get_status', '/get_pixel?x=0&y=0'):
                with self.subTest(endpoint=endpoint):
                    response = self.client.get(endpoint)
                    self.assertEqual(response.status_code, 503)
                    self.assertIn(message, response.get_data(as_text=True))

    def test_draw_line_clips_to_visible_diagonal(self):
        response = self.client.get('/draw_line?x_start=-10&y_start=-10&x_end=10&y_end=10&r=0&g=255&b=0&draw_speed=0')
        self.assertEqual(response.status_code, 200)
        for y in range(8):
            for x in range(8):
                self.assertEqual(self.sense.get_pixel(x, y), [0, 255, 0] if x == y else [0, 0, 0])

    def test_draw_line_handles_directions_and_outside_points(self):
        cases = [((3, -2, 3, 10), {(3, y) for y in range(8)}),
                 ((7, 7, 0, 0), {(n, n) for n in range(8)}),
                 ((4, 4, 4, 4), {(4, 4)}),
                 ((10, 2, -2, 2), {(x, 2) for x in range(8)}),
                 ((0, 7, 7, 0), {(n, 7 - n) for n in range(8)}),
                 ((-3, -1, -3, 9), set())]
        for coords, points in cases:
            with self.subTest(coords=coords):
                self.sense.clear((0, 0, 0))
                params = dict(zip(('x_start', 'y_start', 'x_end', 'y_end'), coords))
                params.update(r=255, g=0, b=0, draw_speed=0)
                self.assertEqual(self.client.get('/draw_line', query_string=params).status_code, 200)
                for y in range(8):
                    for x in range(8):
                        self.assertEqual(self.sense.get_pixel(x, y), [255, 0, 0] if (x, y) in points else [0, 0, 0])

    def test_production_mysensehat_class_is_used(self):
        self.assertEqual(type(self.sense).__name__, 'MySenseHat')
        self.assertTrue(issubclass(type(self.sense), FakeSenseHat))
        self.sense.set_pixel(8, 0, 255, 0, 0)
        self.sense.set_pixel(2, 3, 300, -10.5, 255)
        self.assertEqual(self.sense.get_pixel(2, 3), [255, 0, 255])

    def test_mysensehat_accepts_positional_colour_tuple(self):
        self.sense.set_pixel('2', '3', (300, -10.5, 127.6))
        self.assertEqual(self.sense.get_pixel(2, 3), [255, 0, 128])

    def test_mysensehat_ignores_invalid_numeric_pixel_without_changing_display(self):
        self.assertEqual(type(self.sense).__name__, 'MySenseHat')
        before = self.sense.get_pixels()
        self.sense.set_pixel('kein Wert', 0, 255, 0, 0)
        self.sense.set_pixel(0, 0, float('nan'), 0, 0)
        self.assertEqual(self.sense.get_pixels(), before)

    def test_logs_are_at_page_end_and_html_escaped(self):
        payload = '<script>alert(1)</script>'
        self.client.get('/show_message', query_string={'text_string': payload})
        response = self.client.get('/')
        html = response.get_data(as_text=True)
        self.assertTrue('show_message' in html[html.rfind('Test-Log'):], 'Log fehlt am Seitenende')
        self.assertTrue('&lt;script&gt;' in html, 'Log muss HTML maskieren')
        self.assertFalse(payload in html, 'Benutzereingabe darf kein Script-Element erzeugen')
        self.assertTrue(self.module.request_log)

    def test_every_index_link_and_form_is_implemented(self):
        controls = PageControls()
        controls.feed(self.client.get('/').get_data(as_text=True))
        self.assertGreater(len(controls.links), 25)
        for link in controls.links:
            with self.subTest(link=link):
                response = self.client.get(link)
                self.assertEqual(response.status_code, 200)
                body = response.get_data(as_text=True)
                self.assertFalse('not implemented yet' in body, f'Platzhalter-Endpunkt: {link}')
                self.assertFalse('To be implemented!!!!' in body, f'Platzhalter-Log: {link}')
        for form in controls.forms:
            with self.subTest(form=form):
                self.assertEqual(self.client.post(form['action'], data=form['data']).status_code, 200)


if __name__ == '__main__':
    unittest.main()
