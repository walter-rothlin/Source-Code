#!/usr/bin/python

# ------------------------------------------------------------------
# Name  : MLZ_PY2_2026_Reiser_Pasqual.py
# Source: https://raw.githubusercontent.com/walter-rothlin/RaspberryPi4PiPlates/refs/heads/main/Python_Raspberry/04_Sense_Hat/Flask/LN/SenseHat/Vorbereitung/01_SenseHat_Flask.py
#
# Description: Stellt Web-Applikationen und REST-Services für die Steuerung der LED-Matrix
#              und das Auslesen der Sensoren auf dem Sense-Hat

#
#
# Autor: Walter Rothlin
#
# History:
# 01-Jul-2025  Walter Rothlin     Initial Version
# 04-Oct-2025  Walter Rothlin     Prepared for HBU MLZ 2025
# 06-Oct-2025  Walter Rothlin     Defined and implemented all Endpoints
# 08-Oct-2025  Walter Rothlin     Prepared for MLZ
# 26-Oct-2026  Pasqual Reiser     Copied for MLZ 2026 PY2
# ------------------------------------------------------------------

from flask import *
from Class_My_SenseHat import MySenseHat
from time import sleep
from datetime import datetime
import webcolors
import inspect
import json
import urllib.error
import urllib.parse
import urllib.request

# ===========================================
# globale Variablen
# ===========================================
version = 'Pasqual Reiser (V1.0)'
request_log = []

VALID_ROTATIONS = (0, 90, 180, 270)
DEFAULT_PIXEL_COLOUR = (255, 255, 255)

OPENWEATHER_API_KEY = ''
OPENWEATHER_API_KEY_PLACEHOLDER = 'HIER_DEINEN_API_KEY_EINTRAGEN'
OPENWEATHER_URL = 'https://api.openweathermap.org/data/2.5/weather'
WEATHER_DEFAULT_CITY = 'Zurich,CH'


# ===========================================
# Common functions for URL-Parameter handling
# ===========================================
def get_http_parameter(request, name_endpoint='unknown', verbal=False):
    if request.method == "GET":
        all_parameters = dict(request.args)
        if verbal:
            print(f"get_http_parameter: GET: {all_parameters}")
    elif request.method == "POST":
        all_parameters = dict(request.form)
        if verbal:
            print(f"get_http_parameter: POST: {all_parameters}")
    elif request.is_json:
        all_parameters = request.get_json()
        if verbal:
            print(f"get_http_parameter: JSON: {all_parameters}")
    else:
        all_parameters = {}

    call_debug = f'{request.method}: {name_endpoint}({all_parameters})'
    if verbal:
        print(call_debug)
    return all_parameters, call_debug


def log_request(call_debug):
    request_log.append(f"{datetime.now().strftime('%d-%m-%y %H:%M:%S')}: {call_debug}")


def render_index():
    return render_template('index.html', version=version, request_log=request_log)


def convert2Float(value, default_value=None, min=None, max=None):
    try:
        if isinstance(value, str):
            cleaned = value.strip()  # führende/trailing Spaces weg
            cleaned = cleaned.replace(" ", "")  # Spaces löschen
            cleaned = cleaned.replace("'", "")  # Tausendertrenner löschen
            cleaned = cleaned.replace(",", ".")  # Komma durch Punkt ersetzen
            ret_val = float(cleaned)
        else:
            # int, float und andere direkt versuchen
            ret_val = float(value)

        # Min-/Max-Prüfung
        if min is not None and ret_val < min:
            return min
        if max is not None and ret_val > max:
            return max

        return ret_val

    except (TypeError, ValueError):
        return default_value


def convert2Integer(value, default_value=None, min=None, max=None):
    try:
        if isinstance(value, str):
            cleaned = value.strip()  # führende/trailing Spaces weg
            cleaned = cleaned.replace(" ", "")  # Spaces löschen
            cleaned = cleaned.replace("'", "")  # Tausendertrenner löschen
            cleaned = cleaned.replace(",", "")  # Kommas löschen (z. B. 1,234 → 1234)
            ret_val = int(float(cleaned))  # zuerst float, dann int
        else:
            ret_val = int(float(value))  # auch bei int/float/anderen Typen

        # Min-/Max-Prüfung
        if min is not None and ret_val < min:
            return min
        if max is not None and ret_val > max:
            return max

        return ret_val

    except (TypeError, ValueError):
        return default_value


def convert2Boolean(value, default_value=None):
    try:
        if isinstance(value, str):
            cleaned = value.strip().lower()  # führende/trailing Spaces weg + lowercase
            if cleaned in ('1', 'true', 'yes', 'y'):
                return True
            elif cleaned in ('0', 'false', 'no', 'n'):
                return False
            else:
                return default_value
        elif isinstance(value, (int, float)):
            return bool(value)  # 0 -> False, alles andere -> True
        elif isinstance(value, bool):
            return value
        else:
            return default_value
    except Exception:
        return default_value


def convert2RGB_old(value, default_value=None):
    try:
        # Bereits Tuple/List mit 3 Elementen
        if isinstance(value, (tuple, list)) and len(value) == 3:
            return tuple(int(min(max(0, v), 255)) for v in value)

        # String-Verarbeitung
        elif isinstance(value, str):
            cleaned = value.strip().replace("(", "").replace(")", "").replace(" ", "").replace("'", "").lower()

            # Hex-Farbe erkennen
            if cleaned.startswith('#'):
                cleaned = cleaned[1:]
            if len(cleaned) == 6:  # z. B. 'ff00ff'
                r = int(cleaned[0:2], 16)
                g = int(cleaned[2:4], 16)
                b = int(cleaned[4:6], 16)
                return (r, g, b)

            # RGB-Komma- oder Leerzeichen-Format
            if ',' in cleaned:
                parts = cleaned.split(',')
            else:
                parts = cleaned.split()
            if len(parts) != 3:
                return default_value
            return tuple(int(min(max(0, int(p)), 255)) for p in parts)

        # Einzelzahl → Grau
        elif isinstance(value, (int, float)):
            v = int(min(max(0, int(value)), 255))
            return (v, v, v)

        else:
            return default_value

    except Exception:
        return default_value


def convert2RGB(value, default_value=None):
    """
        print(convert2RGB((255,0,128)))        # (255, 0, 128)
        print(convert2RGB([0,128,255]))        # (0, 128, 255)
        print(convert2RGB("255,0,128"))        # (255, 0, 128)
        print(convert2RGB("0 128 255"))        # (0, 128, 255)
        print(convert2RGB("#ff00ff"))          # (255, 0, 255)
        print(convert2RGB("ff00ff"))           # (255, 0, 255)
        print(convert2RGB("red"))              # (255, 0, 0)
        print(convert2RGB("lightblue"))        # (173, 216, 230)
        print(convert2RGB(100))                # (100, 100, 100)
        print(convert2RGB("unknown", default_value=(0,0,0)))  # (0, 0, 0)
    """
    try:
        # Bereits Tuple/List mit 3 Elementen
        if isinstance(value, (tuple, list)) and len(value) == 3:
            return tuple(int(min(max(0, v), 255)) for v in value)

        # String-Verarbeitung
        elif isinstance(value, str):
            cleaned = value.strip().replace(" ", "").replace("'", "").lower()

            # Hex-Farbe
            if cleaned.startswith('#'):
                cleaned = cleaned[1:]
            if len(cleaned) == 6 and all(c in '0123456789abcdef' for c in cleaned):
                r = int(cleaned[0:2], 16)
                g = int(cleaned[2:4], 16)
                b = int(cleaned[4:6], 16)
                return (r, g, b)

            # CSS3-Farbname
            try:
                rgb = webcolors.name_to_rgb(cleaned)
                return (rgb.red, rgb.green, rgb.blue)
            except ValueError:
                pass  # kein bekannter Name, weitermachen

            # RGB-Komma- oder Leerzeichen-Format
            cleaned = cleaned.replace("(", "").replace(")", "")
            print(f'--> cleaned:{cleaned}')
            if ',' in cleaned:
                parts = cleaned.split(',')
            else:
                parts = cleaned.split()

            print(f'--> parts:{parts}')
            if len(parts) != 3:
                return default_value
            return tuple(int(min(max(0, int(p)), 255)) for p in parts)

        # Einzelzahl → Grau
        elif isinstance(value, (int, float)):
            v = int(min(max(0, int(value)), 255))
            return (v, v, v)

        else:
            return default_value

    except Exception:
        return default_value


# ===========================================
# Application and Endpoints
# ===========================================
app = Flask(__name__)
sense = MySenseHat(default_bg_color=(0, 0, 0))
sense.clear()  # LED-Matrix löschen

# ====================
# Overall-Status
# ====================
@app.route('/get_status', methods=['GET'])
def get_status():
    log_request('get_status()')
    return {'LED_Matrix': sense.get_pixels(), **read_meteo_sensor_values()}


# ====================
# LED-Matrix Endpoints
# ====================
@app.route('/set_rotation', methods=['GET', 'POST'])
def set_rotation():
    received_parameter, arguments = get_http_parameter(request, inspect.currentframe().f_code.co_name)
    rotation = convert2Integer(received_parameter.get('r'), 0)
    if rotation not in VALID_ROTATIONS:
        rotation = 0
    redraw = convert2Boolean(received_parameter.get('redraw'), True)

    sense.set_rotation(rotation, redraw)

    log_request(arguments)
    return render_index()


@app.route('/flip_h', methods=['GET', 'POST'])
def flip_h():
    received_parameter, arguments = get_http_parameter(request, inspect.currentframe().f_code.co_name)
    redraw = convert2Boolean(received_parameter.get('redraw'), True)

    sense.flip_h(redraw)

    log_request(arguments)
    return render_index()


@app.route('/flip_v', methods=['GET', 'POST'])
def flip_v():
    received_parameter, arguments = get_http_parameter(request, inspect.currentframe().f_code.co_name)
    redraw = convert2Boolean(received_parameter.get('redraw'), True)

    sense.flip_v(redraw)

    log_request(arguments)
    return render_index()


@app.route('/set_pixels', methods=['GET', 'POST'])
def set_pixels():
    return f'set_pixels() not to be implemented yet!<br/><br/><a href="/">Back</a>'


@app.route('/get_pixels', methods=['GET', 'POST'])
def get_pixels():
    received_parameter, arguments = get_http_parameter(request, inspect.currentframe().f_code.co_name)
    pixels = sense.get_pixels()
    rows = [pixels[y * 8:(y + 1) * 8] for y in range(8)]

    log_request(arguments)
    return {'LED_Matrix': rows}


def get_pixel_colour_parameter(received_parameter):
    if 'pixel' in received_parameter:
        return convert2RGB(received_parameter['pixel'], DEFAULT_PIXEL_COLOUR)

    r = convert2Integer(received_parameter.get('r'), DEFAULT_PIXEL_COLOUR[0], min=0, max=255)
    g = convert2Integer(received_parameter.get('g'), DEFAULT_PIXEL_COLOUR[1], min=0, max=255)
    b = convert2Integer(received_parameter.get('b'), DEFAULT_PIXEL_COLOUR[2], min=0, max=255)
    return (r, g, b)


@app.route('/set_pixel', methods=['GET', 'POST'])
def set_pixel():
    received_parameter, arguments = get_http_parameter(request, inspect.currentframe().f_code.co_name)
    x = convert2Integer(received_parameter.get('x'), 0)
    y = convert2Integer(received_parameter.get('y'), 0)
    pixel_colour = get_pixel_colour_parameter(received_parameter)

    sense.set_pixel(x, y, pixel_color=pixel_colour)

    log_request(arguments)
    return render_index()


@app.route('/get_pixel', methods=['GET', 'POST'])
def get_pixel():
    received_parameter, arguments = get_http_parameter(request, inspect.currentframe().f_code.co_name)
    x = convert2Integer(received_parameter.get('x'), 0)
    y = convert2Integer(received_parameter.get('y'), 0)

    log_request(arguments)
    return {'x': x, 'y': y, 'colour': sense.get_pixel(x, y)}


@app.route('/clear', methods=['GET', 'POST'])
def clear():
    print('clear called!!!')
    received_parameter, arguments = get_http_parameter(request, inspect.currentframe().f_code.co_name, verbal=True)
    print(f'40) {arguments}')
    colour = convert2RGB(received_parameter.get('colour'), (0, 0, 0))

    print(f'40) clear({colour})')
    sense.clear(colour)

    log_request(arguments)
    return render_index()


@app.route('/show_message', methods=['GET', 'POST'])
def show_message():
    received_parameter, arguments = get_http_parameter(request, inspect.currentframe().f_code.co_name)
    text_string = received_parameter.get('text_string', '?')
    scroll_speed = convert2Float(received_parameter.get('scroll_speed'), 0.1, min=0.01, max=1.0)
    text_colour = convert2RGB(received_parameter.get('text_colour'), (255, 255, 255))
    back_colour = convert2RGB(received_parameter.get('back_colour'), (0, 0, 0))

    sense.show_message(text_string, scroll_speed=scroll_speed, text_colour=text_colour, back_colour=back_colour)

    log_request(arguments)
    return render_index()


@app.route('/show_letter', methods=['GET', 'POST'])
def show_letter():
    received_parameter, arguments = get_http_parameter(request, inspect.currentframe().f_code.co_name)
    print(f'2) {arguments}')
    s = received_parameter.get('s', '?')[0]
    text_colour = convert2RGB(received_parameter.get('text_colour'), (255, 255, 255))
    back_colour = convert2RGB(received_parameter.get('back_colour'), (0, 0, 0))

    print(f'2) show_letter({s}, {text_colour}, {back_colour})')
    sense.show_letter(s=s, text_colour=text_colour, back_colour=back_colour)

    log_request(arguments)
    return render_index()

# =====================
# Environmental sensors
# =====================
def read_temperature():
    return {'value': round(sense.get_temperature(), 2), 'unit': 'C'}


def read_pressure():
    return {'value': round(sense.get_pressure(), 2), 'unit': 'mBar'}


def read_humidity():
    return {'value': round(sense.get_humidity(), 2), 'unit': '%'}


def read_meteo_sensor_values():
    return {'Temperature': read_temperature(),
            'Humidity': read_humidity(),
            'Pressure': read_pressure(),
            }


@app.route('/get_temperature', methods=['GET', 'POST'])
def get_temperature():
    received_parameter, arguments = get_http_parameter(request, inspect.currentframe().f_code.co_name)
    log_request(arguments)
    return {'Temperature': read_temperature()}


@app.route('/get_pressure', methods=['GET', 'POST'])
def get_pressure():
    received_parameter, arguments = get_http_parameter(request, inspect.currentframe().f_code.co_name)
    log_request(arguments)
    return {'Pressure': read_pressure()}


@app.route('/get_humidity', methods=['GET', 'POST'])
def get_humidity():
    received_parameter, arguments = get_http_parameter(request, inspect.currentframe().f_code.co_name)
    log_request(arguments)
    return {'Humidity': read_humidity()}


@app.route('/get_meteo_sensor_values', methods=['GET', 'POST'])
def get_meteo_sensor_values():
    received_parameter, arguments = get_http_parameter(request, inspect.currentframe().f_code.co_name)
    log_request(arguments)
    return read_meteo_sensor_values()


def fetch_openweather(city):
    if OPENWEATHER_API_KEY in ('', OPENWEATHER_API_KEY_PLACEHOLDER):
        raise RuntimeError('OPENWEATHER_API_KEY ist im Python-File nicht eingetragen')

    query = urllib.parse.urlencode({'q': city, 'appid': OPENWEATHER_API_KEY, 'units': 'metric', 'lang': 'de'})
    with urllib.request.urlopen(f'{OPENWEATHER_URL}?{query}', timeout=5) as response:
        return json.load(response)


@app.route('/get_weather', methods=['GET', 'POST'])
def get_weather():
    received_parameter, arguments = get_http_parameter(request, inspect.currentframe().f_code.co_name)
    city = received_parameter.get('city', WEATHER_DEFAULT_CITY)

    weather = None
    error = None
    try:
        weather = fetch_openweather(city)
    except (urllib.error.URLError, TimeoutError, RuntimeError) as e:
        error = str(e)

    log_request(arguments)
    return render_template('weather.html', version=version, city=city, weather=weather, error=error)


@app.route('/')
def index():
    return render_index()


@app.route('/LED_Matrix_Tester')
def LED_Matrix_Tester():
    return render_template('LED_Matrix_Tester.html')



# ============================
# Enpoints in MySenseHat Class
# ============================
@app.route('/draw_line', methods=['GET', 'POST'])
def draw_line():
    received_parameter, arguments = get_http_parameter(request, inspect.currentframe().f_code.co_name)
    x_start = convert2Float(received_parameter.get('x_start'), 0)
    y_start = convert2Float(received_parameter.get('y_start'), 0)
    x_end = convert2Float(received_parameter.get('x_end'), 7)
    y_end = convert2Float(received_parameter.get('y_end'), 7)
    r, g, b = get_pixel_colour_parameter(received_parameter)
    draw_speed = convert2Float(received_parameter.get('draw_speed'), 0, min=0, max=1.0)

    sense.draw_line(x_start, y_start, x_end, y_end, r, g, b, draw_speed)

    log_request(arguments)
    return render_index()


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5002)  # auf allen Netzwerk-Interfaces des Raspberry Pi erreichbar