#!/usr/bin/python

# ------------------------------------------------------------------
# Name  : MLZ_PY2_2026_Lobuzov_Rodion.py
# Vorlage: 01_SenseHat_Flask.py
# https://raw.githubusercontent.com/walter-rothlin/RaspberryPi4PiPlates/refs/heads/main/Python_Raspberry/04_Sense_Hat/Flask/LN/SenseHat/Vorbereitung/01_SenseHat_Flask.py
#
# Description: Stellt Web-Applikationen und REST-Services für die Steuerung der LED-Matrix
#              und das Auslesen der Sensoren auf dem Sense-Hat
#
# Autor: Walter Rothlin (Vorlage), Rodion Lobuzov (MLZ 2026)
#
# History:
# 01-Jul-2025  Walter Rothlin     Initial Version
# 04-Oct-2025  Walter Rothlin     Prepared for HBU MLZ 2025
# 06-Oct-2025  Walter Rothlin     Defined and implemented all Endpoints
# 08-Oct-2025  Walter Rothlin     Prepared for MLZ
# 26-Oct-2026  Rodion Lobuzov     MLZ 2026: alle Endpoints, MySenseHat, Request-Log, aufgeräumt
# 26-Oct-2026  Rodion Lobuzov     V1.1: Review eingearbeitet (show_letter s=, inf/nan, draw_line)
# ------------------------------------------------------------------

from flask import Flask, jsonify, render_template, request
from Class_My_SenseHat import MySenseHat
from datetime import datetime
import webcolors
import inspect
import math

# ===========================================
# globale Variablen
# ===========================================
version = 'Rodion Lobuzov (V1.1)'
request_log = []
VALID_ROTATIONS = (0, 90, 180, 270)  # die einzigen Winkel, die sense_hat.set_rotation() annimmt
TIMESTAMP_FORMAT = '%d-%m-%y %H:%M:%S'


# ===========================================
# Common functions for URL-Parameter handling
# ===========================================
def get_http_parameter(request, name_endpoint='unknown', verbal=False):
    if request.method == "GET":
        all_parameters = dict(request.args)
        if verbal:
            print(f"get_http_parameter: GET: {all_parameters}")
    elif request.method == "POST":
        all_parameters = dict(request.form)
        if verbal:
            print(f"get_http_parameter: POST: {all_parameters}")
    elif request.is_json:
        all_parameters = request.get_json()
        if verbal:
            print(f"get_http_parameter: JSON: {all_parameters}")
    else:
        all_parameters = {}

    call_debug = f'{request.method}: {name_endpoint}({all_parameters})'
    if verbal:
        print(call_debug)
    return all_parameters, call_debug


def convert2Float(value, default_value=None, min=None, max=None):
    try:
        if isinstance(value, str):
            cleaned = value.strip()  # führende/trailing Spaces weg
            cleaned = cleaned.replace(" ", "")  # Spaces löschen
            cleaned = cleaned.replace("'", "")  # Tausendertrenner löschen
            cleaned = cleaned.replace(",", ".")  # Komma durch Punkt ersetzen
            ret_val = float(cleaned)
        else:
            # int, float und andere direkt versuchen
            ret_val = float(value)

        # nan ("not a number") ist ein gültiger float, aber jeder Vergleich mit nan ist False:
        # die Min-/Max-Prüfung darunter würde nan durchlassen
        if math.isnan(ret_val):
            return default_value

        # Min-/Max-Prüfung
        if min is not None and ret_val < min:
            return min
        if max is not None and ret_val > max:
            return max

        return ret_val

    except (TypeError, ValueError):
        return default_value


def convert2Integer(value, default_value=None, min=None, max=None):
    try:
        if isinstance(value, str):
            cleaned = value.strip()  # führende/trailing Spaces weg
            cleaned = cleaned.replace(" ", "")  # Spaces löschen
            cleaned = cleaned.replace("'", "")  # Tausendertrenner löschen
            cleaned = cleaned.replace(",", "")  # Kommas löschen (z. B. 1,234 → 1234)
            ret_val = int(float(cleaned))  # zuerst float, dann int
        else:
            ret_val = int(float(value))  # auch bei int/float/anderen Typen

        # Min-/Max-Prüfung
        if min is not None and ret_val < min:
            return min
        if max is not None and ret_val > max:
            return max

        return ret_val

    except (TypeError, ValueError, OverflowError):  # OverflowError: int(float('inf'))
        return default_value


def convert2Boolean(value, default_value=None):
    try:
        if isinstance(value, str):
            cleaned = value.strip().lower()  # führende/trailing Spaces weg + lowercase
            if cleaned in ('1', 'true', 'yes', 'y'):
                return True
            elif cleaned in ('0', 'false', 'no', 'n'):
                return False
            else:
                return default_value
        elif isinstance(value, (int, float)):
            return bool(value)  # 0 -> False, alles andere -> True
        elif isinstance(value, bool):
            return value
        else:
            return default_value
    except Exception:
        return default_value


def convert2RGB(value, default_value=None):
    """
        print(convert2RGB((255,0,128)))        # (255, 0, 128)
        print(convert2RGB([0,128,255]))        # (0, 128, 255)
        print(convert2RGB("255,0,128"))        # (255, 0, 128)
        print(convert2RGB("0 128 255"))        # (0, 128, 255)
        print(convert2RGB("#ff00ff"))          # (255, 0, 255)
        print(convert2RGB("ff00ff"))           # (255, 0, 255)
        print(convert2RGB("red"))              # (255, 0, 0)
        print(convert2RGB("lightblue"))        # (173, 216, 230)
        print(convert2RGB(100))                # (100, 100, 100)
        print(convert2RGB("unknown", default_value=(0,0,0)))  # (0, 0, 0)
    """
    try:
        # Bereits Tuple/List mit 3 Elementen
        if isinstance(value, (tuple, list)) and len(value) == 3:
            return tuple(int(min(max(0, v), 255)) for v in value)

        # String-Verarbeitung
        elif isinstance(value, str):
            cleaned = value.strip().replace(" ", "").replace("'", "").lower()

            # Hex-Farbe
            if cleaned.startswith('#'):
                cleaned = cleaned[1:]
            if len(cleaned) == 6 and all(c in '0123456789abcdef' for c in cleaned):
                r = int(cleaned[0:2], 16)
                g = int(cleaned[2:4], 16)
                b = int(cleaned[4:6], 16)
                return (r, g, b)

            # CSS3-Farbname
            try:
                rgb = webcolors.name_to_rgb(cleaned)
                return (rgb.red, rgb.green, rgb.blue)
            except ValueError:
                pass  # kein bekannter Name, weitermachen

            # RGB-Komma- oder Leerzeichen-Format
            cleaned = cleaned.replace("(", "").replace(")", "")
            if ',' in cleaned:
                parts = cleaned.split(',')
            else:
                parts = cleaned.split()

            if len(parts) != 3:
                return default_value
            # int(float(p)) statt int(p): int("-10.5") wirft ValueError, float("-10.5") nicht
            return tuple(int(min(max(0, int(float(p))), 255)) for p in parts)

        # Einzelzahl → Grau
        elif isinstance(value, (int, float)):
            v = int(min(max(0, int(value)), 255))
            return (v, v, v)

        else:
            return default_value

    except Exception:
        return default_value


# ===========================================
# Application and Endpoints
# ===========================================
app = Flask(__name__)
sense = MySenseHat()  # löscht die LED-Matrix bereits im Konstruktor


# ===========================================
# Hilfsfunktionen für die Endpoints
# ===========================================
def log_request(arguments):
    """Hängt einen Eintrag mit Zeitstempel ans Request-Log an (wird auf der Index-Seite angezeigt)."""
    request_log.append(f"{datetime.now().strftime(TIMESTAMP_FORMAT)}: {arguments}")


def render_index():
    """Antwort aller Aktions-Endpoints: die Index-Seite mit Version und Request-Log."""
    return render_template('index.html', version=version, request_log=request_log)


def read_temperature():
    """Temperatur als Dictionary mit Wert und Einheit."""
    return {'value': sense.get_temperature(), 'unit': '°C'}


def read_humidity():
    """Relative Luftfeuchtigkeit als Dictionary mit Wert und Einheit."""
    return {'value': sense.get_humidity(), 'unit': '%'}


def read_pressure():
    """Luftdruck als Dictionary mit Wert und Einheit."""
    return {'value': sense.get_pressure(), 'unit': 'mBar'}


def read_meteo_sensor_values():
    """Alle drei Umweltsensoren in einem Dictionary."""
    return {'Temperature': read_temperature(),
            'Humidity': read_humidity(),
            'Pressure': read_pressure(),
            }


# ====================
# Overall-Status
# ====================
@app.route('/get_status', methods=['GET'])
def get_status():
    _, arguments = get_http_parameter(request, inspect.currentframe().f_code.co_name)
    log_request(arguments)
    status = read_meteo_sensor_values()
    status['LED_Matrix'] = sense.get_pixels()
    return jsonify(status)


# ====================
# LED-Matrix Endpoints
# ====================
@app.route('/set_rotation', methods=['GET', 'POST'])
def set_rotation():
    received_parameter, arguments = get_http_parameter(request, inspect.currentframe().f_code.co_name)
    log_request(arguments)
    rotation = convert2Integer(received_parameter.get('r'), 0)
    if rotation not in VALID_ROTATIONS:
        rotation = 0  # so verlangt es der Test: 135° ergibt 0°
    redraw = convert2Boolean(received_parameter.get('redraw'), True)
    sense.set_rotation(rotation, redraw)
    return render_index()


@app.route('/flip_h', methods=['GET', 'POST'])
def flip_h():
    received_parameter, arguments = get_http_parameter(request, inspect.currentframe().f_code.co_name)
    log_request(arguments)
    redraw = convert2Boolean(received_parameter.get('redraw'), True)
    sense.flip_h(redraw)
    return render_index()


@app.route('/flip_v', methods=['GET', 'POST'])
def flip_v():
    received_parameter, arguments = get_http_parameter(request, inspect.currentframe().f_code.co_name)
    log_request(arguments)
    redraw = convert2Boolean(received_parameter.get('redraw'), True)
    sense.flip_v(redraw)
    return render_index()


@app.route('/set_pixels', methods=['GET', 'POST'])
def set_pixels():
    return 'set_pixels() not to be implemented yet!<br/><br/><a href="/">Back</a>'


@app.route('/get_pixels', methods=['GET', 'POST'])
def get_pixels():
    _, arguments = get_http_parameter(request, inspect.currentframe().f_code.co_name)
    log_request(arguments)
    return jsonify({'LED_Matrix': sense.get_pixels()})


@app.route('/set_pixel', methods=['GET', 'POST'])
def set_pixel():
    received_parameter, arguments = get_http_parameter(request, inspect.currentframe().f_code.co_name)
    log_request(arguments)
    x = convert2Integer(received_parameter.get('x'))
    y = convert2Integer(received_parameter.get('y'))
    # Die Farbe kommt entweder als pixel=(r, g, b) oder als einzelne Werte r, g, b
    if 'pixel' in received_parameter:
        colour = convert2RGB(received_parameter.get('pixel'))
    else:
        colour = (convert2Integer(received_parameter.get('r'), 0),
                  convert2Integer(received_parameter.get('g'), 0),
                  convert2Integer(received_parameter.get('b'), 0))
    sense.set_pixel(x, y, colour)
    return render_index()


@app.route('/get_pixel', methods=['GET', 'POST'])
def get_pixel():
    received_parameter, arguments = get_http_parameter(request, inspect.currentframe().f_code.co_name)
    log_request(arguments)
    x = convert2Integer(received_parameter.get('x'))
    y = convert2Integer(received_parameter.get('y'))
    if x is None or y is None:
        return jsonify({'error': 'x und y muessen ganze Zahlen sein'}), 400
    try:
        pixel = sense.get_pixel(x, y)
    except ValueError as error:  # ausserhalb 0..7, die Meldung kommt von sense_hat
        return jsonify({'error': f'get_pixel({x}, {y}): {error}'}), 400
    return jsonify({'x': x, 'y': y, 'pixel': pixel})


@app.route('/clear', methods=['GET', 'POST'])
def clear():
    received_parameter, arguments = get_http_parameter(request, inspect.currentframe().f_code.co_name)
    log_request(arguments)
    colour = convert2RGB(received_parameter.get('colour'), (0, 0, 0))
    sense.clear(colour)
    return render_index()


@app.route('/show_message', methods=['GET', 'POST'])
def show_message():
    received_parameter, arguments = get_http_parameter(request, inspect.currentframe().f_code.co_name)
    log_request(arguments)
    text_string = received_parameter.get('text_string', '')
    # Begrenzt, weil die Antwort erst kommt, wenn der ganze Text durchgelaufen ist
    scroll_speed = convert2Float(received_parameter.get('scroll_speed'), 0.1, min=0.01, max=1.0)
    text_colour = convert2RGB(received_parameter.get('text_colour'), (255, 255, 255))
    back_colour = convert2RGB(received_parameter.get('back_colour'), (0, 0, 0))
    sense.show_message(text_string=text_string, scroll_speed=scroll_speed,
                       text_colour=text_colour, back_colour=back_colour)
    return render_index()


@app.route('/show_letter', methods=['GET', 'POST'])
def show_letter():
    received_parameter, arguments = get_http_parameter(request, inspect.currentframe().f_code.co_name)
    log_request(arguments)
    s = (received_parameter.get('s') or '?')[0]  # 'or' fängt auch s= (leerer String) ab
    text_colour = convert2RGB(received_parameter.get('text_colour'), (255, 255, 255))
    back_colour = convert2RGB(received_parameter.get('back_colour'), (0, 0, 0))
    sense.show_letter(s=s, text_colour=text_colour, back_colour=back_colour)
    return render_index()


# =====================
# Environmental sensors
# =====================
@app.route('/get_temperature', methods=['GET', 'POST'])
def get_temperature():
    _, arguments = get_http_parameter(request, inspect.currentframe().f_code.co_name)
    log_request(arguments)
    return jsonify({'Temperature': read_temperature()})


@app.route('/get_pressure')
def get_pressure():
    _, arguments = get_http_parameter(request, inspect.currentframe().f_code.co_name)
    log_request(arguments)
    return jsonify({'Pressure': read_pressure()})


@app.route('/get_humidity')
def get_humidity():
    _, arguments = get_http_parameter(request, inspect.currentframe().f_code.co_name)
    log_request(arguments)
    return jsonify({'Humidity': read_humidity()})


@app.route('/get_meteo_sensor_values')
def get_meteo_sensor_values():
    _, arguments = get_http_parameter(request, inspect.currentframe().f_code.co_name)
    log_request(arguments)
    return jsonify(read_meteo_sensor_values())


@app.route('/get_weather')
def get_weather():
    _, arguments = get_http_parameter(request, inspect.currentframe().f_code.co_name)
    log_request(arguments)
    # Für die Anzeige gerundet, die JSON-Endpoints liefern die Rohwerte
    rows = [{'name': name, 'value': round(sensor['value'], 1), 'unit': sensor['unit']}
            for name, sensor in read_meteo_sensor_values().items()]
    return render_template('weather.html', version=version, rows=rows,
                           measured_at=datetime.now().strftime(TIMESTAMP_FORMAT))


@app.route('/')
def index():
    return render_index()


@app.route('/LED_Matrix_Tester')
def LED_Matrix_Tester():
    return render_template('LED_Matrix_Tester.html')


# ============================================
# Endpoints, die es nur mit MySenseHat gibt
# ============================================
@app.route('/draw_line', methods=['GET', 'POST'])
def draw_line():
    received_parameter, arguments = get_http_parameter(request, inspect.currentframe().f_code.co_name)
    log_request(arguments)
    x_start = convert2Integer(received_parameter.get('x_start'))
    y_start = convert2Integer(received_parameter.get('y_start'))
    x_end = convert2Integer(received_parameter.get('x_end'))
    y_end = convert2Integer(received_parameter.get('y_end'))
    r = convert2Integer(received_parameter.get('r'))
    g = convert2Integer(received_parameter.get('g'))
    b = convert2Integer(received_parameter.get('b'))
    # Begrenzt, weil die Antwort erst kommt, wenn die ganze Linie gezeichnet ist
    draw_speed = convert2Float(received_parameter.get('draw_speed'), 0.0, min=0.0, max=1.0)
    sense.draw_line(x_start, y_start, x_end, y_end, r, g, b, draw_speed)
    return render_index()


if __name__ == '__main__':
    # 0.0.0.0 = auf allen Adressen des Pi erreichbar, egal welche IP er im aktuellen Netz hat
    app.run(debug=True, host='0.0.0.0', port=5002)
