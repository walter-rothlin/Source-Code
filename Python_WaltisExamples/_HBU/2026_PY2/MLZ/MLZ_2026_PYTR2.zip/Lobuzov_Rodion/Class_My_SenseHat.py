#!/usr/bin/env python3
from __future__ import annotations

from sense_hat import SenseHat
from time import sleep


class MySenseHat(SenseHat):

    X_MIN = 0
    X_MAX = 7
    Y_MIN = 0
    Y_MAX = 7

    def __init__(self, default_background_color: tuple[int, int, int] = (0, 0, 0), default_foreground_color: tuple[int, int, int] = (255, 0, 0),) -> None:
        self.default_background_color = default_background_color
        self.default_foreground_color = default_foreground_color
        super().__init__()
        self.clear(self.default_background_color)

    # konvertiere int, float, str zu int
    @staticmethod
    def _to_int_coord(value: int | float | str) -> int | None:
        try:
            if isinstance(value, str):
                value = value.strip().replace(",", ".")
            return int(round(float(value)))
        except (TypeError, ValueError):
            return None

    def _in_bounds(self, x: int, y: int) -> bool:
        return self.X_MIN <= x <= self.X_MAX and self.Y_MIN <= y <= self.Y_MAX

    # ganze Zahlen von lo bis hi, aber nur innerhalb der Matrix:
    # Punkte ausserhalb würde set_pixel ohnehin überspringen, sie kosten nur Zeit (sleep)
    @staticmethod
    def _range_in_matrix(lo: float, hi: float, limit_min: int, limit_max: int) -> range:
        return range(max(round(lo), limit_min), min(round(hi), limit_max) + 1)

    def _resolve_color(self, r: int | float | str | tuple | list | None = None, g: int | float | str | None = None, b: int | float | str | None = None) -> tuple[int, int, int] | None:
        try:
            if isinstance(r, (tuple, list)) and len(r) == 3 and g is None and b is None:
                r, g, b = r
            if r is None or g is None or b is None:
                r, g, b = self.default_foreground_color
            ri = int(round(float(r)))
            gi = int(round(float(g)))
            bi = int(round(float(b)))
            return (max(0, min(255, ri)), max(0, min(255, gi)), max(0, min(255, bi)))
        except (TypeError, ValueError):
            return None

    # überschreibe SenseHat.set_pixel
    def set_pixel(
        self,
        x: int | float | str,
        y: int | float | str,
        r: int | float | str | tuple | list | None = None,
        g: int | float | str | None = None,
        b: int | float | str | None = None,
    ) -> None:
        xi = self._to_int_coord(x)
        yi = self._to_int_coord(y)
        if xi is None or yi is None:
            print(f"Fehler: ungültige Koordinaten x={x!r}, y={y!r}")
            return

        color = self._resolve_color(r, g, b)
        if color is None:
            print(f"Fehler: ungültige Farbe r={r!r}, g={g!r}, b={b!r}")
            return

        if not self._in_bounds(xi, yi):
            print(f"Warnung: ({xi}, {yi}) ausserhalb 0..7 - set_pixel der Oberklasse nicht aufgerufen")
            return

        super().set_pixel(xi, yi, *color)

    # zeichne eine Linie von (x_start, y_start) nach (x_end, y_end)
    def draw_line(
        self,
        x_start: int | float | str,
        y_start: int | float | str,
        x_end: int | float | str,
        y_end: int | float | str,
        r: int | None = None,
        g: int | None = None,
        b: int | None = None,
        draw_speed: float = 0.0,
    ) -> None:
        try:
            x1 = float(str(x_start).strip().replace(",", "."))
            y1 = float(str(y_start).strip().replace(",", "."))
            x2 = float(str(x_end).strip().replace(",", "."))
            y2 = float(str(y_end).strip().replace(",", "."))
        except (TypeError, ValueError):
            print(f"Fehler: ungültige Linien-Koordinaten ({x_start},{y_start})->({x_end},{y_end})")
            return

        color = self._resolve_color(r, g, b)
        if color is None:
            print("Fehler: ungültige Linienfarbe")
            return

        # vertikale Linie
        if x1 == x2:
            y_lo, y_hi = sorted((y1, y2))
            for y in self._range_in_matrix(y_lo, y_hi, self.Y_MIN, self.Y_MAX):
                self.set_pixel(x1, y, *color)
                sleep(draw_speed)
            return

        # Gerade: y = a*x + b
        a = (y1 - y2) / (x1 - x2)
        intercept = y1 - a * x1

        if abs(a) > 1:
            # Steil: über y laufen, x = (y - b) / a -> grosse Auflösung
            y_lo, y_hi = sorted((y1, y2))
            for y in self._range_in_matrix(y_lo, y_hi, self.Y_MIN, self.Y_MAX):
                x = (y - intercept) / a
                self.set_pixel(x, y, *color)
                sleep(draw_speed)
        else:
            # Flach: über x laufen, y = a*x + b
            x_lo, x_hi = sorted((x1, x2))
            for x in self._range_in_matrix(x_lo, x_hi, self.X_MIN, self.X_MAX):
                y = a * x + intercept
                self.set_pixel(x, y, *color)
                sleep(draw_speed)


# teste die MySenseHat-Klasse
def run_tests() -> None:
    red = (255, 0, 0)
    green = (0, 255, 0)
    blue = (0, 0, 255)
    white = (255, 255, 255)

    # erzeuge ein Objekt der MySenseHat-Klasse
    sense = MySenseHat()

    # setze ein Pixel im Bereich
    print("set_pixel(4, 5) rot")
    sense.set_pixel(4, 5, *red)
    sleep(1)

    # 1.2 Pixel ausserhalb (ohne Override würde das crashen)
    print("set_pixel(8, 5) grün - ausserhalb, darf nicht crashen")
    sense.set_pixel(8, 5, *green)
    sleep(1)

    # Dezimalzahlen (Runden)
    print("set_pixel mit Float: 2.4, 3.6")
    sense.clear()
    sense.set_pixel(2.4, 3.6, *blue)
    sleep(1)

    # Strings + Fehlerbehandlung
    print('set_pixel mit Strings: "1", "6.2" / ungültig "abc"')
    sense.set_pixel("1", "6.2", *white)
    sense.set_pixel("abc", 3, *red)
    sleep(1)

    # draw_line: normale Linie
    print("draw_line Diagonale (0,0)->(7,7)")
    sense.clear()
    sense.draw_line(0, 0, 7, 7, *white)
    sleep(1)

    # draw_line: vertikal
    print("draw_line vertikal (3,0)->(3,7)")
    sense.clear()
    sense.draw_line(3, 0, 3, 7, *red)
    sleep(1)

    # draw_line: steil |a| > 1
    print("draw_line steil (1,0)->(2,7)")
    sense.clear()
    sense.draw_line(1, 0, 2, 7, *green)
    sleep(1)

    # draw_line: Start/Ende ausserhalb (set_pixel fängt ab)
    print("draw_line ausserhalb (-2,-2)->(10,10)")
    sense.clear()
    sense.draw_line(-2, -2, 10, 10, *blue)
    sleep(1)

    sense.clear()
    print("Tests fertig.")


if __name__ == "__main__":
    run_tests()
