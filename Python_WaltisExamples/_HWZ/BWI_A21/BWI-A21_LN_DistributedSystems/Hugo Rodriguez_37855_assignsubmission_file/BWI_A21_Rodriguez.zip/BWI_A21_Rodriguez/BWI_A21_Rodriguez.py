from flask import Flask, render_template, request, redirect, url_for, session, flash

app = Flask(__name__)
app.secret_key = 'your_secret_key'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/kontakt')
def kontakt():
    return render_template('kontakt.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        if email and password and password == email.split('@')[0]:  # Simple check
            session['user'] = email
            return redirect(url_for('index'))
        else:
            flash("Invalid email or password", "danger")
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('index'))

@app.route('/adress_liste')
def adress_liste():
    if 'user' not in session:
        return redirect(url_for('login'))
    addresses = [
        {"name": "Hugo Rodriguez", "address": "Musterstraße 1, 12345 Musterstadt"},
        {"name": "Walter Rothlin", "address": "Beispielweg 2, 67890 Beispielstadt"},
    ]
    return render_template('adress_liste.html', addresses=addresses)

@app.route('/forgot_password', methods=['POST'])
def forgot_password():
    email = request.form['email']
    # Simulate sending email
    flash(f'Password reset link sent to {email}', 'info')
    return redirect(url_for('index'))

@app.route('/register', methods=['POST'])
def register():
    title = request.form['title']
    first_name = request.form['first_name']
    last_name = request.form['last_name']
    email = request.form['email']
    password = request.form['password']
    # Simulate sending registration email
    flash(f'Registration successful for {email}', 'success')
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=5001)