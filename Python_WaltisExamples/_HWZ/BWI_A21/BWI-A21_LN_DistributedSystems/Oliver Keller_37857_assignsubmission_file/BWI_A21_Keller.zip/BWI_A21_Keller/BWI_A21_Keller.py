from flask import Flask, render_template, url_for, redirect, session
from forms import LoginForm, RegistrationForm, ResetPasswordForm

app = Flask(__name__)
app.secret_key = 'supersecretkey'


@app.route('/')
@app.route('/home')
def home():  # put application's code here
    return render_template("index.html", title='Home')


@app.route('/kontakt')
def kontakt():
    return render_template("kontakt.html", title='Kontakt')


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        if form.email.data == 'hwz@hwz.ch' and form.password.data == 'hwz@hwz.ch':
            session['user'] = form.email.data
            return redirect(url_for('home'))
        else:
            return 'Invalid email or password'
    return render_template("login.html", title='Login', form=form)


@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('home'))


@app.route('/adress_liste')
def adress_liste():
    return render_template('adress_liste.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        return redirect(url_for('login'))
    return render_template('register.html', form=form)


@app.route('/password_reset', methods=['GET', 'POST'])
def password_reset():
    form = ResetPasswordForm()
    if form.validate_on_submit():
        return redirect(url_for('login'))
    return render_template('passwort_reset.html', form=form)


if __name__ == '__main__':
    app.run(debug=True)
