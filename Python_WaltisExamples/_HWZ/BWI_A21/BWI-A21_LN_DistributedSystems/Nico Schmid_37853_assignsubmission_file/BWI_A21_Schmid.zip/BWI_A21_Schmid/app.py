from flask import Flask, render_template, url_for, flash, redirect, session
from forms import LoginForm, RegistrationForm
from flask_session import Session

from datetime import datetime

app = Flask(__name__)
app.config['SECRET_KEY'] = '73607e5aee97be1304b2f96eedbbdb37'
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

def handle_login(form):
    if form.email.data == 'Nico' and form.password.data == 'Pass123!':
        session["name"] = form.email.data
        flash('Erfolgreich eingeloggt!', 'success')
        return True
    else:
        flash('Anmeldung fehlgeschlagen. Bitte Benutzernamen und Passwort überprüfen.', 'danger')
        return False

def get_form():
    form = LoginForm()
    form.validate_on_submit()
    return form

@app.route("/")
@app.route("/index", methods=['GET', 'POST'])
def index():
    form = get_form()
    if form.is_submitted() and handle_login(form):
        return redirect(url_for('address_list'))
    return render_template('index.html', form=form)

@app.route("/contact", methods=['GET', 'POST'])
def contact():
    form = get_form()
    if form.is_submitted() and handle_login(form):
        return redirect(url_for('address_list'))
    return render_template('contact.html', title='Kontakt', form=form)

@app.route("/address_list", methods=['GET', 'POST'])
def address_list():
    if not session.get("name"):
        return redirect("/index")
    form = get_form()
    if form.is_submitted() and handle_login(form):
        return redirect(url_for('address_list'))
    return render_template('address_list.html', title='Adress Liste', contact_list = True, form=form)

@app.route('/logout')
def logout():  # put application's code here
    session["name"] = None
    flash('Sie wurden erfolgreich abgemeldet!', 'success')
    return redirect(url_for('index'))

@app.route('/registration', methods=['GET', 'POST'])
def registration():  # put application's code here
    form = RegistrationForm()
    if form.validate_on_submit():
        return redirect(url_for('index'))
    return render_template('registration.html', title="Registration", form=form)

if __name__ == '__main__':
    app.run()
