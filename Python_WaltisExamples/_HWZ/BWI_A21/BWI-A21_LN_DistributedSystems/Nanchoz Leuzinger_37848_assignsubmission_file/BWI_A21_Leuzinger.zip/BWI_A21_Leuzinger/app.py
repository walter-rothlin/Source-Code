from flask import Flask, render_template, request, redirect, url_for, session, flash

app = Flask(__name__)
"""
Quelle aus dem Lernvideo myhwz
https://youtu.be/UIJKdCIEXUQ
"""
app.config['SECRET_KEY'] = '4babf55eb90a9ff353a8dd1be481f575'

users = {
    'nanchoz.leuzinger@gmx.ch': '0787335526',
    'diego.lienhard@gmail.com': '17031999'
}

"""
def user_login() wurd mit ChatGPT erstellt
"""
@app.route('/login', methods=['GET', 'POST'])
def user_login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        if email in users and users[email] == password:
            # gültiges Login
            session['email'] = email
            return redirect(url_for('login_success'))
        else:
            # ungültiges Login, zeigt eine Fehlermeldung
            error = 'Falsche Logindaten, bitte versuchen Sie es erneut!'
            return render_template('login.html', error=error)

    return render_template('login.html')

@app.route('/login/success')
def login_success():
    if 'email' in session:
        return render_template('login_success.html', email=session['email'])
    return redirect(url_for('user_login'))

@app.route('/logout')
def logout():
    session.pop('email', None)
    flash('You have been logged out.')
    return redirect(url_for('user_login'))

"""
Quelle aus den Lernvideos von myhwz 
https://youtu.be/MwZwr5Tvyxo
"""

@app.route('/')
@app.route('/home')
def home():
    return render_template('index.html')

@app.route('/kontakt')
def kontakt():
    return render_template('kontakt.html', title='Kontakt')

@app.route('/address-list')
def address_list():
    if 'email' not in session:
        return redirect(url_for('user_login'))
    return render_template('adress_liste.html', title='Adressen')
"""
Quelle aus den Lernvideos von myhwz sowie aus dem Unterricht
"""
if __name__ == '__main__':
    app.run(debug=True, port=5001)
